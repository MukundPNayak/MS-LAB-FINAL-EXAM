package com.example.Teacher.service;

import com.example.Teacher.model.Teacher;
import com.example.Teacher.repository.TeacherRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeacherService {

    private final TeacherRepository teacherRepository;

    public TeacherService(TeacherRepository teacherRepository) {
        this.teacherRepository = teacherRepository;
    }

    public List<Teacher> getAllTeachers() {
        return teacherRepository.findAll();
    }

    public Teacher getTeacher(String teacherID) {
        return teacherRepository.findById(teacherID).orElse(null);
    }


    public Teacher create(Teacher teacher) {
        return teacherRepository.save(teacher);
    }

    public void delete(String teacherId) {
        teacherRepository.deleteById(teacherId);
    }

    public void deleteAll() {
        teacherRepository.deleteAll();
    }
}
