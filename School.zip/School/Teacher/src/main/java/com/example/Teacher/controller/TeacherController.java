package com.example.Teacher.controller;

import com.example.Teacher.model.Teacher;
import com.example.Teacher.service.TeacherService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/teacher")
@RestController
public class TeacherController {
    private final TeacherService teacherService;

    public TeacherController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    @GetMapping("/getAllTeachers")
    public List<Teacher> getAllTeachers() {
        return teacherService.getAllTeachers();
    }

    @GetMapping("/get/{teacherID}")
    public Teacher getTeacher(@PathVariable String teacherID) {
        return teacherService.getTeacher(teacherID);
    }

    @PostMapping("/createTeacher")
    public Teacher createTeacher(@RequestBody Teacher teacher) {
        return teacherService.create(teacher);
    }

    @DeleteMapping("/deleteTeacher/{teacherId}")
    public String deleteTeacher(@PathVariable String teacherId) {
        teacherService.delete(teacherId);
        return "Teacher deleted";
    }


    @DeleteMapping("/deleteAll")
    public String deleteTeachers() {
        teacherService.deleteAll();
        return "All teachers deleted";
    }
}
