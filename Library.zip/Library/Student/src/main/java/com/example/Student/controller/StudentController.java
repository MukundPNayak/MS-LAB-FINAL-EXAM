package com.example.Student.controller;

import com.example.Student.model.Student;
import com.example.Student.service.StudentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/student")
@RestController
public class StudentController {
    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping("/getAllStudents")
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    @GetMapping("/get/{studentID}")
    public Student getStudent(@PathVariable String studentID) {
        return studentService.getStudent(studentID);
    }

    @PostMapping("/createStudent")
    public Student createStudent(@RequestBody Student student) {
        return studentService.create(student);
    }

    @DeleteMapping("/deleteStudent/{studentId}")
    public String deleteStudent(@PathVariable String studentId) {
        studentService.delete(studentId);
        return "Student deleted";
    }

   

    @DeleteMapping("/deleteAll")
    public String deleteStudents() {
        studentService.deleteAll();
        return "All students deleted";
    }
}
