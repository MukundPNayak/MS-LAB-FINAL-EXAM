package com.example.Student.service;

import com.example.Student.model.Student;
import com.example.Student.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    private final StudentRepository studentRepository;

    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudent(String studentID) {
        return studentRepository.findById(studentID).orElse(null);
    }


    public Student create(Student student) {
        return studentRepository.save(student);
    }

    public void delete(String studentId) {
        studentRepository.deleteById(studentId);
    }

    public void deleteAll() {
        studentRepository.deleteAll();
    }
}
