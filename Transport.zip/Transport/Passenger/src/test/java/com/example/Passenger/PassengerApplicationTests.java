package com.example.Passenger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassengerApplicationTests {

	@Test
	void contextLoads() {
	}

}
