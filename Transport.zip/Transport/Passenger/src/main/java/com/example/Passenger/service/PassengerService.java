package com.example.Passenger.service;

import com.example.Passenger.model.Passenger;
import com.example.Passenger.repository.PassengerRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PassengerService {

    private final PassengerRepository passengerRepository;

    public PassengerService(PassengerRepository passengerRepository) {
        this.passengerRepository = passengerRepository;
    }

    public List<Passenger> getAllPassengers() {
        return passengerRepository.findAll();
    }

    public Passenger getPassenger(String passengerID) {
        return passengerRepository.findById(passengerID).orElse(null);
    }


    public Passenger create(Passenger passenger) {
        return passengerRepository.save(passenger);
    }

    public void delete(String passengerId) {
        passengerRepository.deleteById(passengerId);
    }

    public void deleteAll() {
        passengerRepository.deleteAll();
    }
}
