package com.example.Passenger.controller;

import com.example.Passenger.model.Passenger;
import com.example.Passenger.service.PassengerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/passenger")
@RestController
public class PassengerController {
    private final PassengerService passengerService;

    public PassengerController(PassengerService passengerService) {
        this.passengerService = passengerService;
    }

    @GetMapping("/getAllPassengers")
    public List<Passenger> getAllPassengers() {
        return passengerService.getAllPassengers();
    }

    @GetMapping("/get/{passengerID}")
    public Passenger getPassenger(@PathVariable String passengerID) {
        return passengerService.getPassenger(passengerID);
    }

    @PostMapping("/createPassenger")
    public Passenger createPassenger(@RequestBody Passenger passenger) {
        return passengerService.create(passenger);
    }

    @DeleteMapping("/deletePassenger/{passengerId}")
    public String deletePassenger(@PathVariable String passengerId) {
        passengerService.delete(passengerId);
        return "Passenger deleted";
    }


    @DeleteMapping("/deleteAll")
    public String deletePassengers() {
        passengerService.deleteAll();
        return "All passengers deleted";
    }
}
