package com.example.Operator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OperatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
