package com.example.Operator.controller;

import com.example.Operator.model.Operator;
import com.example.Operator.service.OperatorService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/operator")
@RestController
public class OperatorController {
    private final OperatorService operatorService;

    public OperatorController(OperatorService operatorService) {
        this.operatorService = operatorService;
    }

    @GetMapping("/getAllOperators")
    public List<Operator> getAllOperators() {
        return operatorService.getAllOperators();
    }

    @GetMapping("/get/{operatorID}")
    public Operator getOperator(@PathVariable String operatorID) {
        return operatorService.getOperator(operatorID);
    }

    @PostMapping("/createOperator")
    public Operator createOperator(@RequestBody Operator operator) {
        return operatorService.create(operator);
    }

    @DeleteMapping("/deleteOperator/{operatorId}")
    public String deleteOperator(@PathVariable String operatorId) {
        operatorService.delete(operatorId);
        return "Operator deleted";
    }


    @DeleteMapping("/deleteAll")
    public String deleteOperators() {
        operatorService.deleteAll();
        return "All operators deleted";
    }
}
