package com.example.Operator.service;

import com.example.Operator.model.Operator;
import com.example.Operator.repository.OperatorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OperatorService {

    private final OperatorRepository operatorRepository;

    public OperatorService(OperatorRepository operatorRepository) {
        this.operatorRepository = operatorRepository;
    }

    public List<Operator> getAllOperators() {
        return operatorRepository.findAll();
    }

    public Operator getOperator(String operatorID) {
        return operatorRepository.findById(operatorID).orElse(null);
    }


    public Operator create(Operator operator) {
        return operatorRepository.save(operator);
    }

    public void delete(String operatorId) {
        operatorRepository.deleteById(operatorId);
    }

    public void deleteAll() {
        operatorRepository.deleteAll();
    }
}
