package com.example.Operator.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table 
public class Operator {
    @Id
    private String id;
    @Column
    private String name;
    @Column
    private String count;
	public Operator()
	{
		
	}
    public Operator(String string, String string2, String string3, String string4, String string5) {
        id=string;
		name = string2;
        count=string3;
    }
    

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCount() {
        return this.count;
    }

    public void setCount(String count) {
        this.count = count;
    }
    

}